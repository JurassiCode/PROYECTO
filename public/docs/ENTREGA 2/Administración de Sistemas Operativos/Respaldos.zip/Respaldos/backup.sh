#!/bin/bash

# === Configuración ===
FECHA=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="/home/jurassiuser/PROYECTO/Backups"
WEB_DIR="/home/jurassiuser/PROYECTO/Docker"
DB_NAME="draftosaurus"
DB_USER="root"
DB_PASS="JurassiCode"

# Archivos
SQL_FILE="$BACKUP_DIR/db_$FECHA.sql"
WEB_FILE="$BACKUP_DIR/web_$FECHA.tar.gz"
FINAL_FILE="$BACKUP_DIR/backup_$FECHA.tar.gz"
LOG_FILE="$BACKUP_DIR/backup_$FECHA.log"

# === Inicio de log ===
echo "===== BACKUP iniciado $FECHA =====" >> $LOG_FILE

# === Dump de la base de datos ===
echo "[INFO] Dump de la base de datos..." >> $LOG_FILE
docker exec mysql mysqldump -u$DB_USER -p$DB_PASS $DB_NAME > $SQL_FILE 2>> $LOG_FILE
if [ $? -ne 0 ]; then
  echo "[ERROR] Falló el dump de la base de datos" >> $LOG_FILE
  exit 1
fi

# === Backup de los archivos web ===
echo "[INFO] Backup de archivos web..." >> $LOG_FILE
tar -czf $WEB_FILE -C $WEB_DIR . 2>> $LOG_FILE

# === Empaquetar todo ===
echo "[INFO] Creando archivo final $FINAL_FILE" >> $LOG_FILE
tar -czf $FINAL_FILE -C $BACKUP_DIR $(basename $SQL_FILE) $(basename $WEB_FILE) 2>> $LOG_FILE

# Limpiar temporales
rm $SQL_FILE $WEB_FILE

# === Resultado ===
if [ $? -eq 0 ]; then
  echo "[OK] Backup completado con éxito en $FINAL_FILE" >> $LOG_FILE
else
  echo "[ERROR] Falló la creación del tar final" >> $LOG_FILE
fi

echo "===== BACKUP finalizado $FECHA =====" >> $LOG_FILE
