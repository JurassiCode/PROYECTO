#!/bin/bash

# === Configuración ===
FECHA=$(date +"%Y%m%d_%H%M%S")
LOCAL_BACKUPS="/home/jurassiuser/PROYECTO/Backups/"
REMOTE_USER="jurassiuser"
REMOTE_HOST="10.10.10.2"
REMOTE_DIR="/home/jurassiuser/PROYECTO/Backups/"
LOG_FILE="$LOCAL_BACKUPS/sync_$FECHA.log"

# === Inicio de log ===
echo "===== SYNC iniciado $FECHA =====" >> $LOG_FILE

# === Sincronizar con rsync ===
rsync -avz "$LOCAL_BACKUPS" "${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_DIR}" >> $LOG_FILE 2>&1

# === Resultado ===
if [ $? -eq 0 ]; then
  echo "[OK] Sincronización completada con éxito hacia $REMOTE_HOST:$REMOTE_DIR" >> $LOG_FILE
else
  echo "[ERROR] Falló la sincronización con $REMOTE_HOST" >> $LOG_FILE
fi

echo "===== SYNC finalizado $FECHA =====" >> $LOG_FILE

