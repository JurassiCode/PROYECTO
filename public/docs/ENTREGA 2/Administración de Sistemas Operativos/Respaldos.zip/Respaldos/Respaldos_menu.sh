#!/bin/bash

# === Verificación de superusuario ===
if [ "$EUID" -ne 0 ]; then
    echo "Este script debe ejecutarse como root o con sudo."
    exit 1
fi

# === Variables ===
BACKUP_SCRIPT="/home/jurassiuser/PROYECTO/SCRIPTS/Respaldos/backup.sh"
SYNC_SCRIPT="/home/jurassiuser/PROYECTO/SCRIPTS/Respaldos/sync_backups.sh"
BACKUP_DIR="/home/jurassiuser/PROYECTO/Backups"

# === Función: configurar cron de backups ===
configurar_cron_backups() {
    OPCION=$(dialog --clear --stdout --title "Configurar CRON - Backups" \
        --menu "Selecciona la frecuencia de los backups:" 15 60 5 \
        1 "Diario a las 03:00 (default)" \
        2 "Cada 12 horas" \
        3 "Semanal (domingo 03:00)" \
        4 "Desactivar backups automáticos" \
        5 "Cancelar")

    case $OPCION in
        1) CRON="0 3 * * * $BACKUP_SCRIPT" ;;
        2) CRON="0 */12 * * * $BACKUP_SCRIPT" ;;
        3) CRON="0 3 * * 0 $BACKUP_SCRIPT" ;;
        4) CRON="" ;;
        5) return ;; # cancelar
    esac

    # Editar crontab
    (crontab -l 2>/dev/null | grep -v "$BACKUP_SCRIPT"; [ -n "$CRON" ] && echo "$CRON") | crontab -
    dialog --msgbox "Configuración de backups actualizada." 7 50
}

# === Función: configurar cron de sync remoto ===
configurar_cron_sync() {
    OPCION=$(dialog --clear --stdout --title "Configurar CRON - Sync remoto" \
        --menu "Selecciona la frecuencia de sincronización:" 15 60 5 \
        1 "Semanal (domingo 04:00, default)" \
        2 "Diario a las 04:00" \
        3 "Cada 12 horas" \
        4 "Desactivar sincronización automática" \
        5 "Cancelar")

    case $OPCION in
        1) CRON="0 4 * * 0 $SYNC_SCRIPT" ;;
        2) CRON="0 4 * * * $SYNC_SCRIPT" ;;
        3) CRON="0 */12 * * * $SYNC_SCRIPT" ;;
        4) CRON="" ;;
        5) return ;;
    esac

    (crontab -l 2>/dev/null | grep -v "$SYNC_SCRIPT"; [ -n "$CRON" ] && echo "$CRON") | crontab -
    dialog --msgbox "Configuración de sincronización actualizada." 7 50
}

# === Menú principal ===
CHOICE=0
while [ "$CHOICE" != "7" ]; do
    CHOICE=$(dialog --clear --stdout --title "Gestión de Respaldos" \
        --menu "Selecciona una opción:" 15 60 7 \
        1 "Hacer backup manual" \
        2 "Ver últimos backups" \
        3 "Sincronizar manualmente" \
        4 "Configurar cron (backups)" \
        5 "Configurar cron (sync remoto)" \
        6 "Ver logs" \
        7 "Salir")

    case $CHOICE in
        1) $BACKUP_SCRIPT; dialog --msgbox "Backup ejecutado. Revisar /Backups" 7 50 ;;
        2) ls $BACKUP_DIR/*.tar.gz 2>/dev/null | tail -n 15 > /tmp/backups_list.txt
           dialog --textbox /tmp/backups_list.txt 20 70 ;;
        3) $SYNC_SCRIPT; dialog --msgbox "Sincronización ejecutada." 7 50 ;;
        4) configurar_cron_backups ;;
        5) configurar_cron_sync ;;
        6) ls -1 $BACKUP_DIR/*.log 2>/dev/null | tail -n 10 > /tmp/logs_list.txt
           if [ -s /tmp/logs_list.txt ]; then
               FILE=$(dialog --stdout --menu "Selecciona un log:" 20 70 10 $(awk '{print NR, $0}' /tmp/logs_list.txt))
               [ -n "$FILE" ] && dialog --textbox "$(sed -n ${FILE}p /tmp/logs_list.txt)" 30 80
           else
               dialog --msgbox "No hay logs disponibles." 7 50
           fi ;;
        7) ;;   # salir
        *) break ;;  # ESC rompe el menú
    esac
done
clear
